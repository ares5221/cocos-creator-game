自定义的全局对象
cc.gameData
cc.gameRes
cc.globalData


